package com.example.vrades.viewmodels

import android.arch.lifecycle.ViewModel

class LoginViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}